module.exports=[18522,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_leads_route_actions_8059d9e6.js.map