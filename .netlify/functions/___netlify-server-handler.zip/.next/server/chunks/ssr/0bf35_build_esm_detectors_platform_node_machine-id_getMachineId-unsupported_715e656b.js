module.exports=[478062,a=>{"use strict";var b=a.i(118304);async function c(){b.diag.debug("could not read machine-id: unsupported platform")}a.s(["getMachineId",()=>c])}];

//# sourceMappingURL=0bf35_build_esm_detectors_platform_node_machine-id_getMachineId-unsupported_715e656b.js.map