module.exports=[306458,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_settings_page_actions_765a0cea.js.map