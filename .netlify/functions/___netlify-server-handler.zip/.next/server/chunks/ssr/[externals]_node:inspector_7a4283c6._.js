module.exports=[237221,(a,b,c)=>{b.exports=a.x("node:inspector",()=>require("node:inspector"))}];

//# sourceMappingURL=%5Bexternals%5D_node%3Ainspector_7a4283c6._.js.map