module.exports=[416030,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_performance_page_actions_b2360514.js.map