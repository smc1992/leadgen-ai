module.exports=[422492,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_scrape_route_actions_2a5fbd00.js.map