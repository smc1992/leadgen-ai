module.exports=[217515,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_forecasting_route_actions_66c4ddcc.js.map