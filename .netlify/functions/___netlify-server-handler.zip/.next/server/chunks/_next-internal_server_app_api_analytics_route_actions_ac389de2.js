module.exports=[418125,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_analytics_route_actions_ac389de2.js.map