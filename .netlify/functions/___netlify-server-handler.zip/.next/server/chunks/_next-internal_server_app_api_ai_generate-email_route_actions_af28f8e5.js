module.exports=[846666,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_generate-email_route_actions_af28f8e5.js.map