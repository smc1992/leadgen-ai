module.exports=[631931,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_content_dynamic-blocks_route_actions_ae67dbfc.js.map