module.exports=[422523,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_analytics_route_actions_dcfb890e.js.map