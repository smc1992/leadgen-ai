module.exports=[700914,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_lead-scoring_route_actions_7d249f6d.js.map