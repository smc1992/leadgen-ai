module.exports=[6884,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test-supabase_route_actions_93306397.js.map