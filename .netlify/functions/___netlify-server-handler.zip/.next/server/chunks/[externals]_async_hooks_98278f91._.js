module.exports=[410430,(o,s,e)=>{s.exports=o.x("async_hooks",()=>require("async_hooks"))}];

//# sourceMappingURL=%5Bexternals%5D_async_hooks_98278f91._.js.map