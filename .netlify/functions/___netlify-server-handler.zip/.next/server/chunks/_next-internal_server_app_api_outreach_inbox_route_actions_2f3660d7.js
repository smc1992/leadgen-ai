module.exports=[938295,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_outreach_inbox_route_actions_2f3660d7.js.map