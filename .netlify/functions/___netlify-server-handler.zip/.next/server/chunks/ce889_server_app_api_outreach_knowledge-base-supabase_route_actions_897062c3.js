module.exports=[994806,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_outreach_knowledge-base-supabase_route_actions_897062c3.js.map