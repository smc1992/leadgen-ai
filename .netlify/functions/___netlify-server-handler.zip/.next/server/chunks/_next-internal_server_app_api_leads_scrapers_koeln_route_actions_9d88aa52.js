module.exports=[780277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_leads_scrapers_koeln_route_actions_9d88aa52.js.map