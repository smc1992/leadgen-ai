module.exports=[770566,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_outreach_unsubscribe_route_actions_13455d6a.js.map