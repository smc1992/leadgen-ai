module.exports=[674123,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_setup_forecasts_route_actions_fee1cb00.js.map