globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/db624c42db987e74.js",
    "static/chunks/5198a8c090f6d07d.js",
    "static/chunks/ee4ef5db2df5a4d4.js",
    "static/chunks/89c3948195c0fca1.js",
    "static/chunks/8b181cdae656a3a3.js",
    "static/chunks/turbopack-ad7fcc4a4c1e7589.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];