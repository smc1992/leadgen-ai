var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-env/route.js")
R.c("server/chunks/[root-of-the-server]__f7fafb5d._.js")
R.c("server/chunks/[root-of-the-server]__47cd9b05._.js")
R.c("server/chunks/_next-internal_server_app_api_test-env_route_actions_ca614177.js")
R.m(803053)
module.exports=R.m(803053).exports
