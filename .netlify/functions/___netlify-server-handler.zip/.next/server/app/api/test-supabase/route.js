var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-supabase/route.js")
R.c("server/chunks/[root-of-the-server]__07f6649c._.js")
R.c("server/chunks/[root-of-the-server]__47cd9b05._.js")
R.c("server/chunks/[root-of-the-server]__713835ca._.js")
R.c("server/chunks/_bdf41f67._.js")
R.c("server/chunks/_next-internal_server_app_api_test-supabase_route_actions_93306397.js")
R.m(298120)
module.exports=R.m(298120).exports
