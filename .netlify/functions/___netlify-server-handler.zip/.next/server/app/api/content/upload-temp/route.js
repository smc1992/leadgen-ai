var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/content/upload-temp/route.js")
R.c("server/chunks/[root-of-the-server]__a45ff67b._.js")
R.c("server/chunks/node_modules_next_dist_bfd7b269._.js")
R.c("server/chunks/[root-of-the-server]__47cd9b05._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_content_upload-temp_route_actions_cafadd01.js")
R.m(753928)
module.exports=R.m(753928).exports
